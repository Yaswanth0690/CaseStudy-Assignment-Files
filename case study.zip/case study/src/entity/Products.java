package entity;

public class Products {
    private int productId;
    private String name;
    private double price;
    private String description;
    private int stockQuantity;

    public Products() {
        
    }

    public Products(int productId, String name, double price, String description, int stockQuantity) {
        this.setProductId(productId);
        this.setName(name);
        this.setPrice(price);
        this.setDescription(description);
        this.setStockQuantity(stockQuantity);
    }
    public Products( String name, double price, String description, int stockQuantity) {
        this.setName(name);
        this.setPrice(price);
        this.setDescription(description);
        this.setStockQuantity(stockQuantity);
    }
    public Products(int productId) {
        this.setProductId(productId);
    }
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
}
