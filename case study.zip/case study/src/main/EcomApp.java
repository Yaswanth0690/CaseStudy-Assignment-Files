package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import Myexceptions.CustomerNotFoundException;
import dao.OrderProcessorRepository;
import dao.OrderProcessorRepositoryImpl;
import entity.*;


public class EcomApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final OrderProcessorRepository orderProcessorRepository = new OrderProcessorRepositoryImpl();

    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    createProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                	deleteCustomer();
                	break;
                case 5:
                    addToCart();
                    break;
                case 6:
                    viewCart();
                    break;
                case 7:
                    placeOrder();
                    break;
                case 8:
                    viewCustomerOrders();
                    break;
                case 9:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 9);
    }

   

	private static void displayMenu() {
        System.out.println("===== E-commerce Application Menu =====");
        System.out.println("1. Register Customer");
        System.out.println("2. Create Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Delete Customer");
        System.out.println("5. Add to Cart");
        System.out.println("6. View Cart");
        System.out.println("7. Place Order");
        System.out.println("8. View Customer Orders");
        System.out.println("9. Exit");
        
    }

    private static void registerCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer password: ");
        String password = scanner.nextLine();

        Customers customer = new Customers(name, email, password);
        boolean result = orderProcessorRepository.createCustomer(customer);

        if (result) {
            System.out.println("Customer registered successfully!");
        } else {
            System.out.println("Failed to register customer. Please try again.");
        }
    }

    private static void createProduct() {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product stock quantity: ");
        int stockQuantity = scanner.nextInt();

        Products product = new Products(name, price, description, stockQuantity);
        boolean result = orderProcessorRepository.createProduct(product, name, price, description, stockQuantity);

        if (result) {
            System.out.println("Product created successfully!");
        } else {
            System.out.println("Failed to create product. Please try again.");
        }
    }

    private static void deleteProduct() {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();

        boolean result = orderProcessorRepository.deleteProduct(productId);

        if (result) {
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Failed to delete product. Please check the product ID and try again.");
        }
    }
    
    private static void deleteCustomer() {
        System.out.print("Enter customer ID to delete: ");
        int customerId = scanner.nextInt();

        boolean result = orderProcessorRepository.deleteCustomer(customerId);

        if (result) {
            System.out.println("Customer deleted successfully!");
        } else {
            System.out.println("Failed to delete customer. Please check the customer ID and try again.");
        }
    }


    private static void addToCart() {
        System.out.print("Enter customer email: ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter product ID to add to cart: ");
        int productId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        boolean result = orderProcessorRepository.addToCart(customerEmail, productId, quantity);

        if (result) {
            System.out.println("Product added to the cart successfully!");
        } else {
            System.out.println("Failed to add product to the cart. Please check the input and try again.");
        }
    }

    private static void viewCart() {
        System.out.print("Enter customer email: ");
        String customerEmail = scanner.nextLine();

        List<Products> cartItems = orderProcessorRepository.getAllFromCart(customerEmail);

        if (cartItems != null && !cartItems.isEmpty()) {
            System.out.println("===== Cart Contents =====");
            for (Products product : cartItems) {
                System.out.println("Product: " + product.getName() +
                                   ", Quantity: " + orderProcessorRepository.getAllFromCart(customerEmail));
            }
        } else {
            System.out.println("No items in the cart for the given customer.");
        }
    }

    private static void placeOrder() {
        System.out.print("Enter customer email: ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter shipping address: ");
        String shippingAddress = scanner.nextLine();

        List<Map<Products, Integer>> productsAndQuantities = new ArrayList<>();
        char addMore;
        do {
            System.out.print("Enter product ID to order: ");
            int productId = scanner.nextInt();
            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();

            Map<Products, Integer> productAndQuantity = new HashMap<>();
            productAndQuantity.put(new Products(productId), quantity);
            productsAndQuantities.add(productAndQuantity);
            
            System.out.print("Add more items to the order? (Y/N): ");
            addMore = scanner.next().charAt(0);
            scanner.nextLine(); 
            
        } while (Character.toUpperCase(addMore) == 'Y');

        boolean result = orderProcessorRepository.placeOrder(customerEmail, productsAndQuantities, shippingAddress);

        if (result) {
            System.out.println("Order placed successfully!");
        } else {
            System.out.println("Failed to place order. Please check the input and try again.");
        }
    }

    private static void viewCustomerOrders() {
        System.out.print("Enter customer email: ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String shippingAddress = scanner.nextLine();

        List<Map<Products, Integer>> customerOrders = orderProcessorRepository.getOrdersByCustomer(customerEmail, shippingAddress);

        if (customerOrders != null && !customerOrders.isEmpty()) {
            System.out.println("===== Customer Orders =====");
            for (Map<Products, Integer> order : customerOrders) {
                double totalAmount = 0.0;
                System.out.println("Order Details:");

                for (Map.Entry<Products, Integer> entry : order.entrySet()) {
                    Products product = entry.getKey();
                    int quantity = entry.getValue();

                    System.out.println("Product: " + product.getName() +
                                       ", Quantity: " + quantity +
                                       ", Individual Price: $" + product.getPrice());

                    totalAmount += product.getPrice() * quantity;
                }

                System.out.println("Total Amount for this order: " + totalAmount);
                System.out.println(); 
            }
        } else {
            System.out.println("No orders found for the given customer.");
        }
    }


}
