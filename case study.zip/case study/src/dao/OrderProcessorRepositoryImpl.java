package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Myexceptions.CustomerNotFoundException;
import Myexceptions.OrderNotFoundException;
import Myexceptions.ProductNotFoundException;
import entity.Customers;
import entity.Products;
import util.DBConnUtil;

public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {
    private Connection conn;
    public OrderProcessorRepositoryImpl()  {
        conn = DBConnUtil.getConnection();
    }
      

    // Constructor to initialize the connection, you can add it as needed
    @Override
    public boolean createProduct(Products product, String name, double price, String description, int stockQuantity) {
        String sql = "INSERT INTO products (name, price, description, stockQuantity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, product.getName());
            preparedStatement.setDouble(2, product.getPrice());
            preparedStatement.setString(3, product.getDescription());
            preparedStatement.setInt(4, product.getStockQuantity());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new ProductNotFoundException("Product Creation Failed.");
            }
        } catch (SQLException | ProductNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    @Override
    public boolean createCustomer(Customers customer) {
        String sql = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, customer.getName());
            preparedStatement.setString(2, customer.getEmail());
            preparedStatement.setString(3, customer.getPassword());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new CustomerNotFoundException("Customer Creation Failed.");
            }
        } catch (SQLException | CustomerNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, productId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new ProductNotFoundException("Product with ID " + productId + " not found.");
            }
        } catch (SQLException | ProductNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, customerId);

            int rowsAffected = preparedStatement.executeUpdate();
            
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
            }
        } catch (SQLException | CustomerNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean addToCart(String customerEmail, int productId, int quantity) {
        String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES ((SELECT customer_id FROM customers WHERE email = ?), ?, ?)";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, customerEmail);
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, quantity);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new ProductNotFoundException("Product with ID " + productId + " not found.");
            }
        } catch (SQLException | ProductNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeFromCart(Customers customer, Products product) {
        String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, customer.getCustomerId());
            preparedStatement.setInt(2, product.getProductId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                throw new OrderNotFoundException("Product not found in cart.");
            }
        } catch (SQLException | OrderNotFoundException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Products> getAllFromCart(String customerEmail) {
        List<Products> products = new ArrayList<>();
        String sql = "SELECT p.* FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = (SELECT customer_id FROM customers WHERE email = ?)";
        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, customerEmail);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                Products product = new Products();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setStockQuantity(rs.getInt("stockQuantity"));

                products.add(product);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return products;
    }


    @Override
    public boolean placeOrder(String customerEmail, List<Map<Products, Integer>> productsAndQuantities, String shippingAddress) {
        String orderSQL = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES " +
                "((SELECT customer_id FROM customers WHERE email = ?), CURRENT_DATE(), ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(orderSQL, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, customerEmail);
            double totalPrice = calculateTotalPrice(productsAndQuantities);
            ps.setDouble(2, totalPrice);
            ps.setString(3, shippingAddress);
            

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);

                    String insertOrderItemSQL = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";

                    try (PreparedStatement orderItemPS = conn.prepareStatement(insertOrderItemSQL)) {
                        for (Map<Products, Integer> item : productsAndQuantities) {
                            for (Map.Entry<Products, Integer> entry : item.entrySet()) {
                                Products product = entry.getKey();
                                int quantity = entry.getValue();

                                orderItemPS.setInt(1, orderId);
                                orderItemPS.setInt(2, product.getProductId());
                                orderItemPS.setInt(3, quantity);
                                orderItemPS.addBatch();
                            }
                        }

                        // Execute batch update for order items
                        int[] itemsInserted = orderItemPS.executeBatch();

                        // Check if all items were inserted successfully
                        for (int inserted : itemsInserted) {
                            if (inserted <= 0) {
                                throw new OrderNotFoundException("Failed to insert order items.");
                            }
                        }

                        return true;
                    }
                }
            }
        } catch (SQLException | OrderNotFoundException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    private double calculateTotalPrice(List<Map<Products, Integer>> productsAndQuantities) {
        double totalPrice = 0;

        for (Map<Products, Integer> productAndQuantity : productsAndQuantities) {
            for (Map.Entry<Products, Integer> entry : productAndQuantity.entrySet()) {
                Products product = entry.getKey();
                int quantity = entry.getValue();
                double subtotal = product.getPrice() * quantity;
                totalPrice += subtotal;
            }
        }

        return totalPrice;
    }




	@Override
    public List<Map<Products, Integer>> getOrdersByCustomer(String customerEmail, String shippingAddress) {
        List<Map<Products, Integer>> orders = new ArrayList<>();

        String selectOrdersSQL = "SELECT order_id, shipping_address FROM orders WHERE customer_id = (SELECT customer_id FROM customers WHERE email = ?)";

        try (PreparedStatement orderPS = conn.prepareStatement(selectOrdersSQL)) {
            orderPS.setString(1, customerEmail);

            ResultSet orderRS = orderPS.executeQuery();

            while (orderRS.next()) {
                int orderId = orderRS.getInt("order_id");
                String ShippingAddress = orderRS.getString("shipping_address");

                Map<Products, Integer> order = new HashMap<>();

                String selectOrderItemsSQL = "SELECT product_id, quantity FROM order_items WHERE order_id = ?";

                try (PreparedStatement orderItemPS = conn.prepareStatement(selectOrderItemsSQL)) {
                    orderItemPS.setInt(1, orderId);

                    ResultSet orderItemRS = orderItemPS.executeQuery();

                    while (orderItemRS.next()) {
                        int productId = orderItemRS.getInt("product_id");
                        int quantity = orderItemRS.getInt("quantity");

                        try {
                            Products product = getProductById(productId);
                            order.put(product, quantity);
                        } catch (CustomerNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }

                orders.add(order);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return orders;
    }

    public Products getProductById(int productId) throws CustomerNotFoundException {
        String selectProductSQL = "SELECT * FROM products WHERE product_id = ?";
        try (PreparedStatement productPS = conn.prepareStatement(selectProductSQL)) {
            productPS.setInt(1, productId);

            ResultSet RS = productPS.executeQuery();

            if (RS.next()) {
                int productId1 = RS.getInt("product_id");
                String name = RS.getString("name");
                double price = RS.getDouble("price");
                String description = RS.getString("description");
                int stockQuantity = RS.getInt("stockQuantity");

                Products product = new Products(productId1, name, price, description, stockQuantity);
                product.setProductId(productId1);

                return product;
            } else {
                throw new CustomerNotFoundException("Customer not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new CustomerNotFoundException("Customer not found");
        }
    }

    
}

