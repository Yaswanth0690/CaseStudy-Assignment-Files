package dao;


import java.util.List;
import java.util.Map;

import entity.Customers;
import entity.Products;

public interface OrderProcessorRepository {
    boolean createProduct(Products product, String name, double price, String description, int stockQuantity);
    boolean createCustomer(Customers customer);
    boolean deleteProduct(int productId);
    boolean deleteCustomer(int customerId);
    boolean addToCart(String customerEmail, int productId, int quantity);
    boolean removeFromCart(Customers customer, Products product);
    List<Products> getAllFromCart(String customerEmail);
    public boolean placeOrder(String customerEmail, List<Map<Products, Integer>> productsAndQuantities, String shippingAddress);
	List<Map<Products, Integer>> getOrdersByCustomer(String customerEmail, String shippingAddress);
}