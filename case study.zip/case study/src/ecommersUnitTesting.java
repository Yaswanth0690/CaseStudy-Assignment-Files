import static org.junit.Assert.*;


import org.junit.Test;

import Myexceptions.CustomerNotFoundException;
import Myexceptions.ProductNotFoundException;
import dao.OrderProcessorRepositoryImpl;
import entity.Cart;
import entity.Orders;
import entity.Products;

	public class ecommersUnitTesting {

	    @Test
	    public void testProductCreation() {
	        Products product = new Products("Bonda", 10.99, "Delicious bonda", 0);
	        assertNotNull(product);
	        assertEquals("Bonda", product.getName());
	        assertEquals(10.99, product.getPrice(), 0.001);
	        assertEquals("Delicious bonda", product.getDescription());
	    }

	    @Test
	    public void testAddToCart() {
	        Cart cart = new Cart();
	        Products product = new Products("Dove", 5.49, "Gentle soap", 4);
	        cart.addToCart(product);
	        assertTrue(cart.containsProduct(product));
	    }

	    @Test
	    public void testOrderPlacement() {
	        Cart cart = new Cart();
	        Products product = new Products("Shampoo", 15.99, "For shiny hair", 1);
	        cart.addToCart(product);
	        Orders order = new Orders(cart, "ravi@mail.com");
	        assertTrue(order.placeOrder());
	        assertTrue(order.isOrderPlaced());
	        assertTrue(cart.getCartItems());
	    }


		@Test(expected = CustomerNotFoundException.class)
	    public void testExceptionOnInvalidCustomerId() {
	        Orders order = new Orders(new Cart(), "invalid_customer@example.com");
	        order.placeOrder(); 
	    }

	    @Test(expected = ProductNotFoundException.class)
	    public void testExceptionOnInvalidProductId() {
	        Cart cart = new Cart();
	        cart.addToCart(new Products("InvalidProduct", 9.99, "Invalid product", 0));
	        Orders order = new Orders(cart, "john.doe@example.com");
	        order.placeOrder();
	    }
	    
	    
	    
	    private void assertTrue(Object cartItems) {
			
		}

		
	}


