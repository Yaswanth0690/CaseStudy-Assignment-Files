package Myexceptions;

public class StudentNotFoundException {

	public StudentNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
