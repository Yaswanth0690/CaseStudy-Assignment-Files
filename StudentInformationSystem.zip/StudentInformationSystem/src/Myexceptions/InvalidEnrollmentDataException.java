package Myexceptions;

public class InvalidEnrollmentDataException {

	public InvalidEnrollmentDataException() {
		// TODO Auto-generated constructor stub
	}

}
