package Myexceptions;

public class DuplicateEnrollmentException {

	public DuplicateEnrollmentException() {
		// TODO Auto-generated constructor stub
	}

}
