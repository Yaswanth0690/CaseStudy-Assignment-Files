package Myexceptions;

public class TeacherNotFoundException {

	public TeacherNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
