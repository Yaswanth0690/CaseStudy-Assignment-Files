package Myexceptions;

public class PaymentValidationException {

	public PaymentValidationException() {
		// TODO Auto-generated constructor stub
	}

}
