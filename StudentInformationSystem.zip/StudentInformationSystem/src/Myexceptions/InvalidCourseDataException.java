package Myexceptions;

public class InvalidCourseDataException {

	public InvalidCourseDataException() {
		// TODO Auto-generated constructor stub
	}

}
