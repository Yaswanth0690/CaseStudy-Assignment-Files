package Myexceptions;

public class InsufficientFundsException {

	public InsufficientFundsException() {
		// TODO Auto-generated constructor stub
	}

}
