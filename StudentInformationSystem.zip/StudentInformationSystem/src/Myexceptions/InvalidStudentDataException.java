package Myexceptions;

public class InvalidStudentDataException {

	public InvalidStudentDataException() {
		// TODO Auto-generated constructor stub
	}

}
