package Myexceptions;

public class InvalidTeacherDataException {

	public InvalidTeacherDataException() {
		// TODO Auto-generated constructor stub
	}

}
