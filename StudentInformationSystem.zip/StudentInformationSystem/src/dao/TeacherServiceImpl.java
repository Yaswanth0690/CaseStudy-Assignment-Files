package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Course;
import entity.Teacher;

public class TeacherServiceImpl implements TeacherService {
	private Connection conn;
	public TeacherServiceImpl() {
		conn = Util.DBConnUtil.getConnection();
	}
	@Override
	public void updateTeacherInfo(Teacher teacher, String name, String lastName, String email) {
	    String updateTeacherQuery = "UPDATE teachers SET first_name = ?, last_name = ?, email = ? " +
	                                "WHERE teacher_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(updateTeacherQuery)) {
	        preparedStatement.setString(1, name);
	        preparedStatement.setString(2, lastName);
	        preparedStatement.setString(3, email);
	        preparedStatement.setInt(4, teacher.getTeacherID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher information updated successfully.");
	        } else {
	            System.out.println("Failed to update teacher information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void displayTeacherInfo(Teacher teacher) {
	    String selectTeacherQuery = "SELECT * FROM teachers WHERE teacher_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectTeacherQuery)) {
	        preparedStatement.setInt(1, teacher.getTeacherID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Display teacher information
	                System.out.println("Teacher ID: " + resultSet.getInt("teacher_id"));
	                System.out.println("First Name: " + resultSet.getString("first_name"));
	                System.out.println("Last Name: " + resultSet.getString("last_name"));
	                System.out.println("Email: " + resultSet.getString("email"));
	                System.out.println("Expertise: " + resultSet.getString("expertise"));
	            } else {
	                System.out.println("Teacher not found in the database.");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public List<Course> getAssignedCourses(Teacher teacher) {
	    List<Course> assignedCourses = new ArrayList<>();
	    String selectCoursesQuery = "SELECT * FROM courses WHERE teacher_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCoursesQuery)) {
	        preparedStatement.setInt(1, teacher.getTeacherID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            while (resultSet.next()) {
	                // Create Course object and add to the list
	                Course course = new Course();
	                course.setCourseID(resultSet.getInt("course_id"));
	                course.setCredits(resultSet.getInt("credits"));
	                course.setCourseName(resultSet.getString("course_name"));
	                course.setInstructorName(teacher);  // Set the instructor

	                assignedCourses.add(course);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return assignedCourses;
	}


}
