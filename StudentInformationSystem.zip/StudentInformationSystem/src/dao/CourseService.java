package dao;

import java.util.List;

import entity.Course;
import entity.Student;
import entity.Teacher;

public interface CourseService {
	 void assignTeacher(Course course, Teacher teacher);
	 void updateCourseInfo(Course course, String courseCode, String courseName, String instructor);
	 void displayCourseInfo(Course course);
	 List<Student> getEnrollments(Course course);
	 Teacher getTeacher(Course course);
	}
