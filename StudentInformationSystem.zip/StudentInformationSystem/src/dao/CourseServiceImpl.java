package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Course;
import entity.Student;
import entity.Teacher;

public class CourseServiceImpl implements CourseService {
	private Connection conn;
	public CourseServiceImpl() {
	conn = Util.DBConnUtil.getConnection();
	}

	@Override
	public void assignTeacher(Course course, Teacher teacher) {
	    String Query = "UPDATE courses SET teacher_id = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(Query)) {
	        preparedStatement.setInt(1, Teacher.getTeacherID());
	        preparedStatement.setInt(2, Course.getCourseID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher assigned to the course successfully.");
	        } else {
	            System.out.println("Failed to assign teacher to the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	

	@Override
	public void updateCourseInfo(Course course, String courseCode, String courseName, String instructor) {
	    String updateCourseQuery = "UPDATE courses SET course_code = ?, course_name = ?, instructor = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(updateCourseQuery)) {
	        preparedStatement.setString(1, courseCode);
	        preparedStatement.setString(2, courseName);
	        preparedStatement.setString(3, instructor);
	        preparedStatement.setInt(4, course.getCourseID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Course information updated successfully.");
	        } else {
	            System.out.println("Failed to update course information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void displayCourseInfo(Course course) {
	    String selectCourseQuery = "SELECT * FROM courses WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCourseQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            System.out.println("Course ID: " + resultSet.getInt("course_id"));
	            System.out.println("Course Code: " + resultSet.getString("course_code"));
	            System.out.println("Course Name: " + resultSet.getString("course_name"));
	            System.out.println("Instructor: " + resultSet.getString("instructor"));
	            // Add more fields as needed
	        } else {
	            System.out.println("Course not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public List<Student> getEnrollments(Course course) {
	    List<Student> enrolledStudents = new ArrayList<>();
	    String selectEnrollmentsQuery = "SELECT students.* FROM students " +
	                                    "JOIN enrollments ON students.student_id = enrollments.student_id " +
	                                    "WHERE enrollments.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectEnrollmentsQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        while (resultSet.next()) {
	            Student student = new Student();
	            student.setStudentID(resultSet.getInt("student_id"));
	            student.setFirstName(resultSet.getString("first_name"));
	            student.setLasttName(resultSet.getString("last_name"));
	            student.setDateOfBirth(resultSet.getDate("date_of_birth").toLocalDate());
	            student.setEmail(resultSet.getString("email"));
	            student.setPhoneNumber(resultSet.getString("phone_number"));
	            // Add more fields as needed

	            enrolledStudents.add(student);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledStudents;
	}


	@Override
	public Teacher getTeacher(Course course) {
	    Teacher teacher = null;
	    String selectTeacherQuery = "SELECT teachers.* FROM teachers " +
	                               "JOIN courses ON teachers.teacher_id = courses.teacher_id " +
	                               "WHERE courses.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectTeacherQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            teacher = new Teacher();
	            teacher.setTeacherID(resultSet.getInt("teacher_id"));
	            teacher.setFirstName(resultSet.getString("first_name"));
	            teacher.setLastName(resultSet.getString("last_name"));
	            teacher.setEmail(resultSet.getString("email"));
	            // Add more fields as needed
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return teacher;
	}


}
