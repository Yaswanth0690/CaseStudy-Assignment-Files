package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Payment;
import entity.Student;

public interface StudentService  {
	 void updateStudentInfo(Student student, String firstName, String lastName, String newDateOfBirth, String email, String phoneNumber);
	 boolean makePayment(int studentId, double amount);
	 void displayStudentInfo(Student student);
	 List<Course> getEnrolledCourses(Student student);
	 List<Payment> getPaymentHistory(Student student);
	 boolean enrollInCourse(int studentId, int courseId );
	}
