package dao;

import entity.Course;
import entity.Enrollment;
import entity.Student;

public interface EnrollmentService {
	 Student getStudent2(Enrollment enrollment);
	 Course getCourse(Enrollment enrollment);
	}