package dao;

import java.util.List;

import entity.Course;
import entity.Teacher;

public interface TeacherService  {
	 void updateTeacherInfo(Teacher teacher, String name,String lastName, String email);
	 void displayTeacherInfo(Teacher teacher);
	 List<Course> getAssignedCourses(Teacher teacher);
	}
