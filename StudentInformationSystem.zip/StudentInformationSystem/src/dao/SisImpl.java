package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import entity.Course;
import entity.Student;
import entity.Teacher;

public class SisImpl implements sis{
	private Connection conn;
	public SisImpl() {
		conn = Util.DBConnUtil.getConnection();
	}
	@Override
	public void enrollStudentInCourse(Student student, Course course) {
	    String enrollQuery = "INSERT INTO enrollments (studentID, courseID, enrollment_date) VALUES (?, ?, ?)";
	    Date enrollmentDate = new Date(System.currentTimeMillis()); // Assuming the current date

	    try (PreparedStatement preparedStatement = conn.prepareStatement(enrollQuery)) {
	        preparedStatement.setInt(1, student.getStudentID());
	        preparedStatement.setInt(2, course.getCourseID());
	        preparedStatement.setDate(3, (java.sql.Date) enrollmentDate);

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student enrolled in the course successfully.");
	        } else {
	            System.out.println("Failed to enroll student in the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	@Override
	public void assignTeacherToCourse(Teacher teacher, Course course) {
	    String assignTeacherQuery = "UPDATE courses SET instructor = ? WHERE courseID = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(assignTeacherQuery)) {
	        preparedStatement.setString(1, teacher.getFirstName() + " " + teacher.getLastName());
	        preparedStatement.setInt(2, course.getCourseID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher " + teacher.getFirstName() + " " + teacher.getLastName() +
	                    " assigned to the course " + course.getCourseName() + " successfully.");
	        } else {
	            System.out.println("Failed to assign teacher to the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void recordPayment(Student student, double amount, Date paymentDate) {
	    String recordPaymentQuery = "INSERT INTO payments (studentID, amount, paymentDate) VALUES (?, ?, ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(recordPaymentQuery)) {
	        preparedStatement.setInt(1, student.getStudentID());
	        preparedStatement.setDouble(2, amount);

	        // Convert java.util.Date to java.sql.Date
	        java.sql.Date sqlPaymentDate = new java.sql.Date(paymentDate.getTime());
	        preparedStatement.setDate(3, sqlPaymentDate);

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully for student " + student.getFirstName() +
	                    " " + student.getLasttName() + ". Amount: " + amount + ", Date: " +
	                    new SimpleDateFormat("yyyy-MM-dd").format(paymentDate));
	        } else {
	            System.out.println("Failed to record payment for student " + student.getFirstName() +
	                    " " + student.getLasttName() + ".");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void generateEnrollmentReport(Course course) {
	    String enrollmentReportQuery = "SELECT students.studentID, students.firstName, students.lastName, students.email " +
	            "FROM enrollments " +
	            "INNER JOIN students ON enrollments.studentID = students.studentID " +
	            "WHERE enrollments.courseID = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(enrollmentReportQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        System.out.println("===== Enrollment Report for Course: " + course.getCourseName() + " =====");

	        while (resultSet.next()) {
	            int studentID = resultSet.getInt("studentID");
	            String firstName = resultSet.getString("firstName");
	            String lastName = resultSet.getString("lastName");
	            String email = resultSet.getString("email");

	            System.out.println("Student ID: " + studentID +
	                    ", Name: " + firstName + " " + lastName +
	                    ", Email: " + email);
	        }

	        System.out.println("=============================");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void generatePaymentReport(Student student) {
	    String paymentReportQuery = "SELECT * FROM payments WHERE studentID = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(paymentReportQuery)) {
	        preparedStatement.setInt(1, student.getStudentID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        System.out.println("===== Payment Report for Student: " + student.getFirstName() + " " + student.getLasttName() + " =====");

	        while (resultSet.next()) {
	            int paymentID = resultSet.getInt("paymentID");
	            double amount = resultSet.getDouble("amount");
	            java.sql.Date paymentDate = resultSet.getDate("paymentDate");

	            System.out.println("Payment ID: " + paymentID +
	                    ", Amount: $" + amount +
	                    ", Payment Date: " + paymentDate);
	        }

	        System.out.println("==============================");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void calculateCourseStatistics(Course course) {
	    String enrollmentCountQuery = "SELECT COUNT(*) AS enrollmentCount FROM enrollments WHERE courseID = ?";
	    String totalPaymentsQuery = "SELECT SUM(amount) AS totalPayments FROM payments WHERE courseID = ?";

	    try (PreparedStatement enrollmentCountStatement = conn.prepareStatement(enrollmentCountQuery);
	         PreparedStatement totalPaymentsStatement = conn.prepareStatement(totalPaymentsQuery)) {

	        enrollmentCountStatement.setInt(1, course.getCourseID());
	        totalPaymentsStatement.setInt(1, course.getCourseID());

	        ResultSet enrollmentCountResult = enrollmentCountStatement.executeQuery();
	        ResultSet totalPaymentsResult = totalPaymentsStatement.executeQuery();

	        if (enrollmentCountResult.next() && totalPaymentsResult.next()) {
	            int enrollmentCount = enrollmentCountResult.getInt("enrollmentCount");
	            double totalPayments = totalPaymentsResult.getDouble("totalPayments");

	            System.out.println("===== Course Statistics for " + course.getCourseName() + " =====");
	            System.out.println("Enrollment Count: " + enrollmentCount);
	            System.out.println("Total Payments: $" + totalPayments);
	            System.out.println("==============================");
	        } else {
	            System.out.println("Failed to retrieve course statistics.");
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


}
