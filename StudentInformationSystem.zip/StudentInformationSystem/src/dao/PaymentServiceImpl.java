package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Payment;
import entity.Student;

public class PaymentServiceImpl implements PaymentService {
	private Connection conn;
	public PaymentServiceImpl() {
		conn = Util.DBConnUtil.getConnection();
	}
	@Override
	public Student getStudent(Payment payment) {
	    Student student = null;
	    String selectStudentQuery = "SELECT * FROM students WHERE student_id = (SELECT student_id FROM payments WHERE payment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectStudentQuery)) {
	        preparedStatement.setInt(1, payment.getPaymentID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Student object
	                student = new Student();
	                student.setStudentID(resultSet.getInt("student_id"));
	                student.setFirstName(resultSet.getString("first_name"));
	                student.setLasttName(resultSet.getString("last_name"));
	                // You may want to set other properties based on your database schema
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return student;
	}

	@Override
	public double getPaymentAmount(Payment payment) {
	    double paymentAmount = 0.0;
	    String selectPaymentAmountQuery = "SELECT amount FROM payments WHERE payment_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectPaymentAmountQuery)) {
	        preparedStatement.setInt(1, payment.getPaymentID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Retrieve payment amount
	                paymentAmount = resultSet.getDouble("amount");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentAmount;
	}

	@Override
	public Date getPaymentDate(Payment payment) {
	    Date paymentDate = null;
	    String selectPaymentDateQuery = "SELECT payment_date FROM payments WHERE payment_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectPaymentDateQuery)) {
	        preparedStatement.setInt(1, payment.getPaymentID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Retrieve payment date
	                paymentDate = resultSet.getDate("payment_date");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentDate;
	}


}
