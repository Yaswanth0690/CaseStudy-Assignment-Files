package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Payment;
import entity.Student;

public class StudentServiceImpl implements StudentService {
	private Connection conn;
	public StudentServiceImpl() {
	
	conn = Util.DBConnUtil.getConnection();
	}
	@Override
	public boolean enrollInCourse(int studentId, int courseId ) {
	    
	    String enrollQuery = "INSERT INTO enrollments (student_id, course_id ) VALUES (?,?)";
		try (PreparedStatement preparedStatement = conn.prepareStatement(enrollQuery)) {
	        preparedStatement.setInt(1, studentId);
	        preparedStatement.setInt(2, courseId);
	        

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student enrolled in the course successfully.");
	        } else {
	            System.out.println("Failed to enroll student in the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
		return false;
	}

	@Override
	public void updateStudentInfo(Student student, String firstName, String lastName, String dateOfBirth, String email, String phoneNumber) {
	    
	    String updateQuery = "UPDATE students SET first_name=?, last_name=?, date_of_birth=?, email=?, phone_number=? WHERE studentID=?";

	    try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
	        ps.setString(1, firstName);
	        ps.setString(2, lastName);
	        ps.setString(3, dateOfBirth);
	        ps.setString(4, email);
	        ps.setString(5, phoneNumber);
	        ps.setInt(6, student.getStudentID());

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student information updated successfully.");
	        } else {
	            System.out.println("Failed to update student information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	}

	@Override
	public boolean makePayment(int student, double amount) {
	    String insertQuery = "INSERT INTO payments (student_id, amount) VALUES (?, ?)";

	    try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
	        ps.setInt(1, Student.getStudentID());
	        ps.setDouble(2, amount);
			

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully.");
	        } else {
	            System.out.println("Failed to record payment.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
		return false;
	}


	@Override
	public void displayStudentInfo(Student student) {
	    String selectQuery = "SELECT * FROM students WHERE student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            System.out.println("Student Information:");
	            System.out.println("Student ID: " + rs.getInt("student_id"));
	            System.out.println("First Name: " + rs.getString("first_name"));
	            System.out.println("Last Name: " + rs.getString("last_name"));
	            System.out.println("Date of Birth: " + rs.getDate("date_of_birth"));
	            System.out.println("Email: " + rs.getString("email"));
	            System.out.println("Phone Number: " + rs.getString("phone_number"));
	        } else {
	            System.out.println("Student not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	}


	@Override
	public List<Course> getEnrolledCourses(Student student) {
	    List<Course> enrolledCourses = new ArrayList<>();
	    String selectQuery = "SELECT c.* FROM enrollments e " +
	                        "JOIN courses c ON e.course_id = c.course_id " +
	                        "WHERE e.student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            Course course = new Course();
	            course.setCourseName(rs.getString("course_name"));
	            enrolledCourses.add(course);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledCourses;
	}


	@Override
	public List<Payment> getPaymentHistory(Student student) {
	    List<Payment> paymentHistory = new ArrayList<>();
	    String selectQuery = "SELECT * FROM payments WHERE student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            Payment payment = new Payment();
	            payment.setPaymentID(rs.getInt("payment_id"));
	            payment.setStudentID(rs.getInt("student_id"));
	            payment.setAmount(rs.getDouble("amount"));
	            payment.setPaymentDate(rs.getString("payment_date"));
	            paymentHistory.add(payment);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentHistory;
	}
	
}
