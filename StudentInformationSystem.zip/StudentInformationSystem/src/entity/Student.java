package entity;
import java.time.LocalDate;
import java.util.Date;
public class Student {
	private static int studentID;
	private String firstName;
	private String lasttName;
	private Date dateOfBirth;
	private String email;
	private String phoneNumber;
	public Student() {
		 
	}
	public Student(int studentID, String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lasttName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
	public Student(int studentID) {
        this.studentID = studentID;
	}
	
	
	public Student(int studentid2, int courseid) {
		// TODO Auto-generated constructor stub
	}
	public static int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLasttName() {
		return lasttName;
	}
	public void setLasttName(String lasttName) {
		this.lasttName = lasttName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public void setDateOfBirth(LocalDate localDate) {
		// TODO Auto-generated method stub
		
	}
	
	
}
