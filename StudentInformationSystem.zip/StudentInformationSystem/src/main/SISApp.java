package main;

import java.text.ParseException;
import java.util.List;
import java.util.Scanner;

import dao.*;
import entity.*;
import Util.*;

public class SISApp {

	private static final Scanner scanner = new Scanner(System.in);
    private static final ServiceProvider ServiceProvider = new ServiceProviderImpl();
    private static final StudentService StudentService = new StudentServiceImpl();
    private static final TeacherService TeacherService = new TeacherServiceImpl();
    private static final PaymentService PaymentService = new PaymentServiceImpl();
    private static final CourseService CourseService = new CourseServiceImpl();
    private static final EnrollmentService EnrollmentService = new EnrollmentServiceImpl();

    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    StudentService();
                    break;
                case 2:
                    TeacherService();
                    break;
                case 3:
                    PaymentService();
                    break;
                case 4:
                	CourseService();
                	break;
                case 5:
                    EnrollmentService();
                    break;
                case 6:
                    sis();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
    }

	private static void sis() {
		int choice;
        do {
            sisMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollStudentInCourse();
                    break;
                case 2:
                	assignTeacherToCourse();
                    break;
                case 3:
                	recordPayment();
                    break;
                case 4:
                	generateEnrollmentReport();
                	break;
                case 5:
                	generatePaymentReport();
                    break;
                case 6:
                	calculateCourseStatistics();
                    break;                
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 6);		
	}

	private static void calculateCourseStatistics() {
		// TODO Auto-generated method stub
		
	}

	private static void generatePaymentReport() {
		// TODO Auto-generated method stub
		
	}

	private static void generateEnrollmentReport() {
		// TODO Auto-generated method stub
		
	}

	private static void recordPayment() {
		// TODO Auto-generated method stub
		
	}

	private static void assignTeacherToCourse() {
		// TODO Auto-generated method stub
		
	}

	private static void enrollStudentInCourse() {
		// TODO Auto-generated method stub
		
	}

	private static void sisMenu() {
		System.out.println("===== Welcome to Student Services =====");
        System.out.println("1. Enroll Student In Course");
        System.out.println("2. Assign Teacher to Course");
        System.out.println("3. Make Payment");
        System.out.println("4. View Enrollment Information");
        System.out.println("5. View Payment Information");
        System.out.println("6. Course Statistics");
        System.out.println("7. Exit");		
	}

	private static void EnrollmentService() {
		int choice;
        do {
            EnrollmentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudent2();
                    break;
                case 2:
                	getCourse();
                    break;
                case 3:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 3);			
	}
	private static void getCourse() {
		// TODO Auto-generated method stub
		
	}

	private static void getStudent2() {
		// TODO Auto-generated method stub
		
	}

	private static void EnrollmentMenu() {
		System.out.println("===== Welcome to Enrollment Services =====");
        System.out.println("1. View Assigned Student");
        System.out.println("2. View Assigned Course");
        System.out.println("3. Exit");		
	}

	private static void CourseService() {
		int choice;
        do {
            CourseMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	assignTeacher();
                    break;
                case 2:
                	updateCourseInfo();
                    break;
                case 3:
                	displayCourseInfo();
                    break;
                case 4:
                	getEnrollments();
                	break;
                case 5:
                	getTeacher();
                    break;
                case 6:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 6);		
	}

	private static void getTeacher() {
		// TODO Auto-generated method stub
		
	}

	private static void getEnrollments() {
		// TODO Auto-generated method stub
		
	}

	private static void displayCourseInfo() {
		// TODO Auto-generated method stub
		
	}

	private static void updateCourseInfo() {
		// TODO Auto-generated method stub
		
	}

	private static void assignTeacher() {
		// TODO Auto-generated method stub
		
	}

	private static void CourseMenu() {
		System.out.println("===== Welcome to Course Services =====");
        System.out.println("1. Assign Teacher");
        System.out.println("2. Update Course Information");
        System.out.println("3. View Course Information");
        System.out.println("4. View Course Enrollments");
        System.out.println("5. View Assigned Teacher");
        System.out.println("6. Exit");
		
	}

	private static void PaymentService() {
		int choice;
        do {
            PaymentsMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudent();
                    break;
                case 2:
                	getPaymentAmount();
                    break;
                case 3:
                	getPaymentDate();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);		
	}

	private static void getPaymentDate() {
		// TODO Auto-generated method stub
		
	}

	private static void getPaymentAmount() {
		// TODO Auto-generated method stub
		
	}

	private static void getStudent() {
		// TODO Auto-generated method stub
		
	}

	private static void PaymentsMenu() {
		System.out.println("===== Welcome to Payment Services =====");
        System.out.println("1. View Student Details");
        System.out.println("2. View Payment Amount");
        System.out.println("3. View Payment Date");
        System.out.println("4. Exit");			
	}

	private static void TeacherService() {
		int choice;
        do {
            TeacherMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	updateTeacherInfo();
                    break;
                case 2:
                	displayTeacherInfo();
                    break;
                case 3:
                	getAssignedCourses();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);
		
	}

	private static void getAssignedCourses() {
		// TODO Auto-generated method stub
		
	}

	private static void displayTeacherInfo() {
		// TODO Auto-generated method stub
		
	}

	private static void updateTeacherInfo() {
		// TODO Auto-generated method stub
		
	}

	private static void TeacherMenu() {
		System.out.println("===== Welcome to Teacher Services =====");
        System.out.println("1. Update Teacher Information");
        System.out.println("2. View Teacher Information");
        System.out.println("3. View Assigned Courses");
        System.out.println("4. Exit");		
	}

	private static void StudentService() {
		int choice;
        do {
            StudentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollInCourse();
                    break;
                case 2:
                	updateStudentInfo();
                    break;
                case 3:
                	makePayment();
                    break;
                case 4:
                	displayStudentInfo();
                	break;
                case 5:
                	getEnrolledCourses();
                    break;
                case 6:
                	getPaymentHistory();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
		
	}

	private static void getPaymentHistory() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    Student student = new Student(studentId);

	    // Call the static method on the interface to get payment history
	    List<Payment> paymentHistory = StudentService.getPaymentHistory(student);

	    if (paymentHistory != null && !paymentHistory.isEmpty()) {
	        System.out.println("Payment History for Student ID " + studentId + ":");
	        for (Payment payment : paymentHistory) {
	            System.out.println("Payment ID: " + payment.getPaymentID());
	            System.out.println("Amount: " + payment.getAmount());
	            System.out.println("Payment Date: " + payment.getPaymentDate());
	            System.out.println("============");
	        }
	    } else {
	        System.out.println("No payment history found for the student.");
	    }
	}


	private static void getEnrolledCourses() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();

	    Student student = new Student(studentId);

	    List<Course> enrolledCourses = StudentService.getEnrolledCourses(student);

	    if (enrolledCourses != null && !enrolledCourses.isEmpty()) {
	        System.out.println("Enrolled Courses:");
	        for (Course course : enrolledCourses) {
	            System.out.println(course.getCourseName());
	        }
	    } else {
	        System.out.println("No enrolled courses found for the student.");
	    }
	}


	private static void displayStudentInfo() {

	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    Student student = new Student(studentId); 
	    StudentService.displayStudentInfo(student);
	    
	}


	private static void makePayment() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Payment Amount: ");
	    double amount = scanner.nextDouble();
	    
		boolean result = StudentService.makePayment(studentId, amount);
		
	    

	    if (result) {
	        System.out.println("Payment successful!");
	    } else {
	        System.out.println("Payment failed. Please try again.");
	    }
	}



	private static void updateStudentInfo() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter New First Name: ");
	    String newFirstName = scanner.next();
	    System.out.print("Enter New Last Name: ");
	    String newLastName = scanner.next();
	    System.out.print("Enter New Date of Birth (YYYY-MM-DD): ");
	    String newDateOfBirth = scanner.next();
	    System.out.print("Enter New Email: ");
	    String newEmail = scanner.next();
	    System.out.print("Enter New Phone Number: ");
	    String newPhoneNumber = scanner.next();

	    boolean result = StudentService.updateStudentInfo(studentId, newFirstName, newLastName, newDateOfBirth, newEmail, newPhoneNumber);

	    if (result) {
	        System.out.println("Student information updated successfully!");
	    } else {
	        System.out.println("Failed to update student information. Please try again.");
	    }
	}

	private static void enrollInCourse() {
	    System.out.print("Enter Student Id: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Course Id: ");
	    int courseId = scanner.nextInt();

	    boolean result = StudentService.enrollInCourse(studentId, courseId);

	    if (result) {
	        System.out.println("Student enrolled in the course successfully!");
	    } else {
	        System.out.println("Failed to enroll student in the course. Please try again.");
	    }
	}

	private static void StudentMenu() {
		System.out.println("===== Welcome to Student Services =====");
        System.out.println("1. Enroll A Course");
        System.out.println("2. Update Student Information");
        System.out.println("3. Make Payment");
        System.out.println("4. View Student Information");
        System.out.println("5. Enrolled Courses");
        System.out.println("6. Payment History");
        System.out.println("7. Exit");
		
	}

	private static void displayMenu() {
        System.out.println("===== Student Information System =====");
        System.out.println("1. Student Services");
        System.out.println("2. Teacher Services");
        System.out.println("3. Payment Services");
        System.out.println("4. Course Services");
        System.out.println("5. Enrollment Services");
        System.out.println("6. Quick Services");
        System.out.println("7. Exit");
	}
}
